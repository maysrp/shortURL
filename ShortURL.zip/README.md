## ShortURL
JUST a test for TP5

PHP>5.5

SQL

TP5 

Web ROOT directory /public/

website setting: /application/config.php

database setting:/application/database.php

/runtime 0777





